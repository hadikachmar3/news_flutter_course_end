const String BASEURL = "newsapi.org";
const String API_KEY = "84a442d2ffca4e85832a4b68696ee890"; //84a442d2ffca4e85832a4b68696ee890

// Be careful use your link
const String BASEURL_FIREBASE = "newsteaching-7edbe-default-rtdb.firebaseio.com";